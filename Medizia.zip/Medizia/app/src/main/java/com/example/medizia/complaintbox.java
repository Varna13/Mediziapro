package com.example.medizia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class complaintbox extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaintbox);
    }
}
