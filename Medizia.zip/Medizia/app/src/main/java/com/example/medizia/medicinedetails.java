package com.example.medizia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class medicinedetails extends AppCompatActivity {
    EditText ed1,ed2,ed3;
    Button b1,b2;
    TableLayout t1;
    int i;
    TextView tabname,tabquant;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicinedetails);
        ed1=(EditText)findViewById(R.id.medicinenumber);
        b1=(Button)findViewById(R.id.add);
        b2=(Button)findViewById(R.id.ulid);
        t1=(TableLayout)findViewById(R.id.tablet);
        tabname=(TextView)findViewById(R.id.tabname);
        tabquant=(TextView)findViewById(R.id.quan);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i=0;
                int tabnum=Integer.parseInt(ed1.getText().toString().trim());
                tabname.setVisibility(View.VISIBLE);
                tabquant.setVisibility(View.VISIBLE);

                for (i=0;i<tabnum;i++)
                {
                    TableRow trow=new TableRow(getApplicationContext());
                    ed2=new EditText(getApplicationContext());
                    ed2.setText("               ");
                    ed2.setId(i);
                    ed3=new EditText(getApplicationContext());
                    ed3.setText("               ");
                    ed3.setId(i+tabnum);
                    trow.addView(ed2);
                    trow.addView(ed3);
                    t1.addView(trow);

                }



            }
        });
        b2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(Intent.ACTION_GET_CONTENT);

                i.setType("*/*");
                startActivity(i);
                Toast.makeText(getApplicationContext(),"Order successfully placed",Toast.LENGTH_LONG).show();



            }
        });
    }
}
